/**
 * Agent-dir resolution without a hard load-time dependency on pi's exports: tests run `node --test`
 * with no peer deps installed, and older pi versions may not export getAgentDir. Start with the
 * conventional default; upgrade to pi's answer (rebranded distros) when the extension boots.
 */
import { join } from "node:path";
import { homedir } from "node:os";

let agentDir = join(homedir(), ".pi", "agent");

export const agentDirNow = (): string => agentDir;

export async function upgradeAgentDir(): Promise<void> {
  try {
    const m: any = await import("@earendil-works/pi-coding-agent");
    if (typeof m.getAgentDir === "function") agentDir = m.getAgentDir();
  } catch { /* keep the conventional default */ }
}

import test from "node:test";
import assert from "node:assert/strict";
const { resolveLimit } = await import("./trigger.ts");

test("threshold: absolute tokens, percentage of window, and the maxFraction cap", () => {
  const window = 1_000_000;
  // absolute (the default policy: cost is denominated in tokens, not window-fraction)
  assert.equal(resolveLimit({ at: 200_000, maxFraction: 0.75 }, window), 200_000);
  // percentage string → fraction of the window
  assert.equal(resolveLimit({ at: "20%", maxFraction: 0.75 }, window), 200_000);
  assert.equal(resolveLimit({ at: "12.5%", maxFraction: 0.75 }, 200_000), 25_000);
  // maxFraction caps BOTH forms — a typo can never ride to the overflow edge
  assert.equal(resolveLimit({ at: 900_000, maxFraction: 0.75 }, window), 750_000);
  assert.equal(resolveLimit({ at: "90%", maxFraction: 0.75 }, window), 750_000);
  // small-window model: absolute default larger than the window → the cap binds
  assert.equal(resolveLimit({ at: 200_000, maxFraction: 0.75 }, 128_000), 96_000);
});

test("threshold: session override wins, junk strings fall back to the default", () => {
  assert.equal(resolveLimit({ at: 200_000, maxFraction: 0.75 }, 1_000_000, 150_000), 150_000);
  assert.equal(resolveLimit({ at: "garbage", maxFraction: 0.75 }, 1_000_000), 200_000);
  assert.equal(resolveLimit({ at: "%", maxFraction: 0.75 }, 1_000_000), 200_000);
  assert.equal(resolveLimit({ at: -5, maxFraction: 0.75 }, 1_000_000), 200_000);
});

/**
 * Pattern B summarization: instead of re-sending the conversation as a serialized blob under a
 * summarizer system prompt (pi's default — a brand-new cache prefix, full input price every time),
 * send THE LIVE REQUEST ITSELF (same tools, same system prompt, same messages) with one appended
 * user message: "summarize this". The provider's prompt cache then re-reads the whole prefix at
 * the cacheRead rate (~1/10th of input), because byte-for-byte it has seen it before.
 *
 * Measured before building (2026-09-13, playground/cache-probe): a thinking-level change does NOT
 * invalidate Anthropic's cache; a model change does. So this runs on the SESSION model, thinking
 * off. Whether the prefix truly matches in production is a fact, not a hope: the summarizer's own
 * usage.cacheRead lands in compaction.log next to the context size.
 *
 * The input is TRUNCATED at the kept boundary (firstKeptEntryId): the summarizer sees only the
 * doomed portion, so summary and kept-verbatim tail never overlap. This still rides the cache —
 * probe-verified (playground/cache-probe/probe3.mjs, 2026-09-13): every past request left an entry
 * at its last user message, and any later full-prefix read refreshes the WHOLE chain, so at
 * compaction time (fired at agent_settled, seconds after live calls) the interior boundary is
 * warm. Miss worst case = pattern-A price once, visible in the log's cacheRead column.
 */

export type LlmMessage = { role: string; content: unknown[]; timestamp?: number };
type ToolInfo = { name: string; description?: string; parameters?: unknown };
type Completion = { stopReason: string; errorMessage?: string; content: Array<{ type: string; text?: string }>; usage?: UsageIn };
type UsageIn = { input: number; output: number; cacheRead: number; cacheWrite: number; cost?: { total?: number; input?: number; output?: number; cacheRead?: number; cacheWrite?: number } };

export type AppendedDeps = {
  complete: (model: unknown, context: unknown, options: Record<string, unknown>) => Promise<Completion>;
  /** ctx branch entries → LLM messages, exactly as the live loop does it (buildContextEntries → sessionEntryToContextMessages → convertToLlm). */
  entriesToLlm: (ctx: AppendedCtx, firstKeptEntryId?: string) => LlmMessage[];
};

export type AppendedCtx = {
  getSystemPrompt(): string;
  getAllTools(): ToolInfo[];
  getActiveTools(): string[];
};

export type AppendedRequest = {
  prep: { firstKeptEntryId: string; tokensBefore: number };
  model: unknown;
  apiKey?: string;
  headers?: Record<string, string>;
  env?: Record<string, string>;
  signal?: AbortSignal;
  ctx: AppendedCtx;
  maxTokens: number;
  /** The SESSION's thinking level. Anthropic invalidates the MESSAGE cache when thinking parameters
   *  change (tools/system spans survive — which is why the cache-probe, whose cached span was all
   *  system, wrongly measured thinking as cache-neutral). Mirror the live value or lose the prefix. */
  thinkingLevel?: unknown;
};

/** pi's own compaction prompt (dist/core/compaction/compaction.js, not exported) — written to sit
 *  AFTER the conversation, which is exactly where Pattern B puts it. Kept verbatim so summaries
 *  keep the checkpoint structure every other part of the system already expects. */
export const SUMMARIZE_INSTRUCTION = `The messages above are a conversation to summarize. Create a structured context checkpoint summary that another LLM will use to continue the work.

Use this EXACT format:

## Goal
[What is the user trying to accomplish? Can be multiple items if the session covers different tasks.]

## Constraints & Preferences
- [Any constraints, preferences, or requirements mentioned by user]
- [Or "(none)" if none were mentioned]

## Progress
### Done
- [x] [Completed tasks/changes]

### In Progress
- [ ] [Current work]

### Blocked
- [Issues preventing progress, if any]

## Key Decisions
- **[Decision]**: [Brief rationale]

## Next Steps
1. [Ordered list of what should happen next]

## Critical Context
- [Any data, examples, or references needed to continue]
- [Or "(none)" if not applicable]

Keep each section concise. Preserve exact file paths, function names, and error messages.
const UPDATE_SUMMARIZATION_INSTRUCTIONS = \`Update the existing structured summary with new information. RULES:
- PRESERVE all existing information from the previous summary
- ADD new progress, decisions, and context from the new messages
- UPDATE the Progress section: move items from "In Progress" to "Done" when completed
- UPDATE "Next Steps" based on what was accomplished
- PRESERVE exact file paths, function names, and error messages
- If something is no longer relevant, you may remove it

Use this EXACT format:

## Goal
[Preserve existing goals, add new ones if the task expanded]

## Constraints & Preferences
- [Preserve existing, add new ones discovered]

## Progress
### Done
- [x] [Include previously done items AND newly completed items]

### In Progress
- [ ] [Current work - update based on progress]

### Blocked
- [Current blockers - remove if resolved]

## Key Decisions
- **[Decision]**: [Brief rationale] (preserve all previous, add new)

## Next Steps
1. [Update based on current state]

## Critical Context
- [Preserve important context, add new if needed]

Keep each section concise. Preserve exact file paths, function names, and error messages.`;

const RETRY_INSTRUCTION = `${SUMMARIZE_INSTRUCTION}

IMPORTANT: Do NOT call tools. Reply with ONLY the summary text in the format above.`;

export function buildAppendedContext(args: { systemPrompt: string; messages: LlmMessage[]; tools: ToolInfo[]; instruction: string }) {
  return {
    systemPrompt: args.systemPrompt,
    messages: [...args.messages, { role: "user", content: [{ type: "text", text: args.instruction }], timestamp: Date.now() }],
    tools: args.tools,
  };
}

const addUsage = (a: UsageIn | undefined, b: UsageIn | undefined): UsageIn | undefined => {
  if (!a) return b;
  if (!b) return a;
  return {
    input: a.input + b.input, output: a.output + b.output,
    cacheRead: a.cacheRead + b.cacheRead, cacheWrite: a.cacheWrite + b.cacheWrite,
    cost: { total: (a.cost?.total ?? 0) + (b.cost?.total ?? 0) },
  };
};

/** Entries strictly before the kept boundary. Unknown or leading id → the full ledger:
 *  degrade to pattern B rather than summarize nothing or lose the request. */
export function sliceDoomed<T extends { id?: string }>(entries: T[], firstKeptEntryId?: string): T[] {
  if (!firstKeptEntryId) return entries;
  const cut = entries.findIndex((e) => e.id === firstKeptEntryId);
  return cut > 0 ? entries.slice(0, cut) : entries;
}

export async function appendedCompact(deps: AppendedDeps, req: AppendedRequest) {
  const { ctx } = req;
  const byName = new Map(ctx.getAllTools().map((t) => [t.name, t]));
  // Active tools in ACTIVE order — the tools array is the first bytes of the cache prefix.
  const tools = ctx.getActiveTools().map((n) => byName.get(n)).filter((t): t is ToolInfo => !!t);
  const messages = deps.entriesToLlm(ctx, req.prep.firstKeptEntryId);
  const options: Record<string, unknown> = {
    apiKey: req.apiKey, headers: req.headers, env: req.env, signal: req.signal,
    maxTokens: req.maxTokens, cacheRetention: "short",
  };
  if (req.thinkingLevel && req.thinkingLevel !== "off") options.reasoning = req.thinkingLevel;

  let usage: UsageIn | undefined;
  for (const instruction of [SUMMARIZE_INSTRUCTION, RETRY_INSTRUCTION]) {
    const context = buildAppendedContext({ systemPrompt: ctx.getSystemPrompt(), messages, tools, instruction });
    const r = await deps.complete(req.model, context, options);
    usage = addUsage(usage, r.usage);
    if (r.stopReason === "error" || r.stopReason === "aborted") throw new Error(r.errorMessage || `summarizer ${r.stopReason}`);
    if (r.stopReason === "toolUse") continue; // same prefix, firmer instruction — still one cache hit
    const summary = r.content.filter((b) => b.type === "text").map((b) => b.text ?? "").join("").trim();
    if (!summary) throw new Error("summarizer returned an empty summary");
    return { summary, firstKeptEntryId: req.prep.firstKeptEntryId, tokensBefore: req.prep.tokensBefore, usage };
  }
  throw new Error("summarizer insisted on calling tools twice; giving up");
}

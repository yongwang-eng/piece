# pi-background-compact

Background context compaction for the [pi coding agent](https://pi.dev) — the
summarizer **rides the live prompt cache**, the summary is spliced in at the next pause, and the
conversation is **never blocked**.

```
pi's built-in compaction            pi-instant-compact
────────────────────────            ──────────────────
blocks the conversation             runs in the background
fires near the window edge          fires at YOUR token budget
re-sends everything at full price   re-reads the prefix at cache price
```

Measured on a real 193k-token session (claude-fable-5-1):

| | serializing summarizer | this extension |
|---|---|---|
| summarizer input bill | ~193k tokens at full input price (**$3.09** observed) | 191,249 tokens cache-read + **2** at full price (**$0.46**, of which ~$0.40 is the summary's own output) |
| editor blocked | ~1–6 min | never |

## Install

```bash
pi install npm:pi-background-compact     # or: pi install /path/to/checkout
```

## How it works

```
 your turn ends (agent_settled)
   │  tokens > threshold − lead?
   ▼
 summarize in the BACKGROUND
   │  the request = your live request (same tools, system prompt,
   │  messages, thinking config — byte-identical prefix) + ONE
   │  appended user message: "summarize this conversation"
   │  → the provider re-reads the prefix at the cacheRead rate
   ▼
 summary ready
   │  applied at the next settled boundary — never mid-run
   │  fingerprint check: same session, same cut point, no other
   │  compaction landed → otherwise DROPPED, never force-fit
   ▼
 spliced: [summary][recent tail] — your draft and your flow untouched
```

The cache hit is a **recorded fact, not a hope**: every summarizer call logs its own `cacheRead`
next to the context size in `~/.pi/agent/state/compaction.log`.

### Why the prefix matches

A full cache hit requires: same model, same thinking configuration, byte-identical
tools/system/messages. The summarizer therefore runs on the **session model** with the
**session's thinking level** — a cheaper summarizer model would guarantee a full cache miss and
cost ~10× more. (Thinking-config changes invalidate the message cache while the tools/system
spans survive — easy to mismeasure, expensive to ignore.)

## Configuration

`~/.pi/agent/settings.json`:

All of this package's settings live under **`backgroundCompact`** — deliberately NOT `autoCompact`
(pi core's own overflow-guard toggle) or `compaction` (pi core's block; its `keepRecentTokens` /
`reserveTokens` are respected as-is).

```jsonc
{
  "backgroundCompact": {
    "at": 200000,        // absolute token threshold (economic policy, not window edge)
    "lead": 10000,       // start summarizing this many tokens early
    "maxFraction": 0.75, // never exceed this fraction of the model window
    "minGapMs": 60000,   // one compaction must land before the next starts
    "enabled": true,
    "background": true,  // false → plain blocking compaction at the threshold
    "strategy": "appended",  // "pi" → pi's serializing summarizer (full price)
    "notify": true       // false → transition log only (bring your own UI)
  }
}
```

Commands: `/autocompact` (show/set threshold: `120k` · `now` · `reset`) ·
`/compact-bg` (compact now in the background; `status` · `cancel`).

## Failure design — nothing ever blocks

| what goes wrong | what happens |
|---|---|
| appended summarizer fails | falls back to pi's serializing summarizer (logged) |
| ledger changed before apply (manual /compact, branch switch) | summary dropped; spent cost logged |
| reload/shutdown mid-flight | summarization aborted and logged |
| service unavailable | trigger falls back to pi's blocking compaction |
| everything above fails | pi's own overflow guard still compacts at the window edge |

## Observability

- `~/.pi/agent/state/compaction.log` — every transition (started/ready/applied/dropped/FAILED)
  with token counts, cost, elapsed time, and the summarizer's `cacheRead`
- notifications for the three outcomes you must not miss (applied / dropped / failed);
  mute with `"backgroundCompact": { "notify": false }`
- `background-compaction:{started,ready,applied,dropped,failed}` on `pi.events` for other
  extensions (e.g. a usage ledger) — `dropped` carries the summarizer's usage so discarded work
  is still billed exactly once

## UI

The package ships **no custom UI** — status widgets are a matter of taste, and the events bus is
the API. [`examples/status-row.ts`](examples/status-row.ts) is a complete, copyable status-row
extension (`⟳ compacting 193k in background · 35s` under the editor, with an elapsed ticker);
drop it in your extensions folder and restyle freely.

## Prior art

Claude Code shipped "instant auto-compacting" in 2.0.64 (Dec 2025). pi issue
[#160](https://github.com/earendil-works/pi/issues/160) proposed porting it and was declined as
too wasteful — a fair objection to *speculative, full-price* summarization. This extension
removes both terms of that objection: it summarizes **once** (at threshold − lead, not after
every turn) and at **cache price** (the appended-instruction request). Related:
[#6606](https://github.com/earendil-works/pi/issues/6606),
[#6919](https://github.com/earendil-works/pi/issues/6919).

## Caveats

- Reaches into pi internals for two functions pi does not export at root
  (`prepareCompaction`, pi-ai's `completeSimple`); resolved defensively at load — if resolution
  fails the extension degrades to pi's blocking compaction and says so.
- Cache-hit economics verified on Anthropic models (5-minute cache TTL). Other providers fall
  back gracefully: worst case is pi's normal compaction price, never worse.
- The post-splice call pays a one-time partial rewrite (~the summary + kept tail as cache
  writes); that is the irreducible price of the ledger genuinely changing.
